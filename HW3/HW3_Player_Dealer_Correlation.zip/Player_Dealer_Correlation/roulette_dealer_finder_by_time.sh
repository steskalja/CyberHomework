#!/bin/bash

cat $1* | awk -F"\t" '{print$1,$3}' | grep "^$2" 


