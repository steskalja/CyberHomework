#!/bin/bash

cat * | awk -F"\t" '{print$1,$3}' | grep "^$1" >> Dealers_working_during_losses.txt
